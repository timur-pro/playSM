package models

import org.joda.time.DateTime

case class DeviceView(name: String,
                      label: String,
                      uid: String,
                      description: String,
                      syncDate: DateTime,
                      visible: Boolean,
                      reliable: Boolean,
                      withOutCrc: Int
                     ) {

}
