package models

import java.time.LocalDate

case class DirWithoutCat(path: String, date: LocalDate) {

}
