package ru.ns.model

/**
  * Created by ns on 15.02.2019.
  */
case class SmPath(fParent: String
                 )

